import 'dart:ui';

class AppColor {
  AppColor._();


  static const Color backgroundColor = Color.fromRGBO(9, 27, 75, 1);
}