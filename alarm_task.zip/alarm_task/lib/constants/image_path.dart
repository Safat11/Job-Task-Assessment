class AppImagePath{
static String image1 = 'assets/images/onboard1.png';
static String image2 = 'assets/images/onboard2.png';
static String image3 = 'assets/images/onboard3.png';
static String image4 = 'assets/images/onboard4.png';


}