class AppRoutes {
  AppRoutes._privateConstructor();


  ///////////////App Screen////////////////////////////////////
  static const splashScreen = "/splashScreen";

  static const onboardingScreen = "/onboardingScreen";
  static const homeScreen = "/homeScreen";
  static const alarmScreen = "/alarmScreen";
  static const addAlarmScreen = "/addAlarmScreen";





}
